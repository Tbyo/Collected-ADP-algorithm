function xout=fiveagent(t,x)

%global variables
global kappa1;
global kappa2;
global kappa3;

global R11;
global R13;
global R14;
global R22;
global R21;
global R31;
global R32;
global R33;
global R41;
global R44;
global R45;
global R52;
global R54;
global R55;

global A;
global B1;
global B2;
global B3;
global B4;
global B5;

global Q11;
global Q22;
global Q33;
global Q44;
global Q55;

global d1;
global d2;
global d3;
global d4;
global d5;

global g1;
global g2;
global g3;
global g4;
global g5;
global i;


%constants 

a1=3;
a2=3;
a3=3;
a4=3;
a5=3;

a6=1;
a7=1;
a8=1;
a9=1;
a10=1;

delta1=[x(1) x(2)]';
delta2=[x(3) x(4)]';
delta3=[x(5) x(6)]';
delta4=[x(7) x(8)]';
delta5=[x(9) x(10)]';

W1=[x(11) x(12) x(13) x(14) x(15) x(16) x(17) x(18) x(19) x(20) x(21) x(22) x(23) x(24) x(25)]';
W2=[x(26) x(27) x(28) x(29) x(30) x(31) x(32) x(33) x(34) x(35) x(36) x(37) x(38) x(39) x(40)]';
W3=[x(41) x(42) x(43) x(44) x(45) x(46) x(47) x(48) x(49) x(50) x(51) x(52) x(53) x(54) x(55)]';
W4=[x(56) x(57) x(58) x(59) x(60) x(61) x(62) x(63) x(64) x(65) x(66) x(67) x(68) x(69) x(70)]';
W5=[x(71) x(72) x(73) x(74) x(75) x(76) x(77) x(78) x(79) x(80) x(81) x(82) x(83) x(84) x(85)]';

W6=[x(86) x(87) x(88) x(89) x(90) x(91) x(92) x(93) x(94) x(95) x(96) x(97) x(98) x(99) x(100)]';
W7=[x(101) x(102) x(103) x(104) x(105) x(106) x(107) x(108) x(109) x(110) x(111) x(112) x(113) x(114) x(115)]';
W8=[x(116) x(117) x(118) x(119) x(120) x(121) x(122) x(123) x(124) x(125) x(126) x(127) x(128) x(129) x(130)]';
W9=[x(131) x(132) x(133) x(134) x(135) x(136) x(137) x(138) x(139) x(140) x(141) x(142) x(143) x(144) x(145)]';
W10=[x(146) x(147) x(148) x(149) x(150) x(151) x(152) x(153) x(154) x(155) x(156) x(157) x(158) x(159) x(160)]';

x1=[x(161) x(162)]';
x2=[x(163) x(164)]';
x3=[x(165) x(166)]';
x4=[x(167) x(168)]';
x5=[x(169) x(170)]';
x0=[x(171) x(172)]';


phi1=[x(1)^2 x(1)*x(2) x(2)^2 0 0 0 x(5)^2 x(5)*x(6) x(6)^2 x(7)^2 x(7)*x(8) x(8)^2 0 0 0]';
dphi1=[2*x(1) 0; x(2) x(1); 0 2*x(2);0 0;0 0;0 0;2*x(5) 0; x(6) x(5); 0 2*x(6);2*x(7) 0; x(8) x(7); 0 2*x(8);0 0;0 0;0 0];
phi2=[x(1)^2 x(1)*x(2) x(2)^2 x(3)^2 x(3)*x(4) x(4)^2 0 0 0 0 0 0 0 0 0]';
dphi2=[2*x(1) 0; x(2) x(1);0 2*x(2);2*x(3) 0; x(4) x(3);0 2*x(4);0 0;0 0;0 0;0 0;0 0;0 0;0 0;0 0;0 0];
phi3=[x(1)^2 x(1)*x(2) x(2)^2 x(3)^2 x(3)*x(4) x(4)^2 x(5)^2 x(5)*x(6) x(6)^2 0 0 0 0 0 0]';
dphi3=[2*x(1) 0; x(2) x(1);0 2*x(2);2*x(3) 0;x(4) x(3);0 2*x(4);2*x(5) 0;x(6) x(5);0 2*x(6);0 0;0 0;0 0;0 0;0 0;0 0];
phi4=[x(1)^2 x(1)*x(2) x(2)^2 0 0 0 0 0 0 x(7)^2 x(7)*x(8) x(8)^2 x(9)^2 x(9)*x(10) x(10)^2]';
dphi4=[2*x(1) 0;x(2) x(1);0 2*x(2);0 0;0 0;0 0;0 0;0 0;0 0;2*x(7) 0;x(8) x(7);0 2*x(8);2*x(9) 0;x(10) x(9);0 2*x(10)];
phi5=[0 0 0 x(3)^2 x(3)*x(4) x(4)^2 0 0 0 x(7)^2 x(7)*x(8) x(8)^2 x(9)^2 x(9)*x(10) x(10)^2]';
dphi5=[0 0;0 0;0 0;2*x(3) 0;x(4) x(3);0 2*x(4);0 0;0 0;0 0;2*x(7) 0;x(8) x(7);0 2*x(8);2*x(9) 0;x(10) x(9);0 2*x(10)];


u1=-0.5*(d1+g1)*inv(R11)*B1'*dphi1'*W6;
u2=-0.5*(d2+g2)*inv(R22)*B2'*dphi2'*W7;
u3=-0.5*(d3+g3)*inv(R33)*B3'*dphi3'*W8;
u4=-0.5*(d4+g4)*inv(R44)*B4'*dphi4'*W9;
u5=-0.5*(d5+g5)*inv(R55)*B5'*dphi5'*W10;

s1=dphi1*(A*delta1+(d1+g1)*B1*u1-B3*u3-B4*u4);
s2=dphi2*(A*delta2+(d2+g2)*B2*u2-B1*u1);
s3=dphi3*(A*delta3+(d3+g3)*B3*u3-B1*u1-B2*u2);
s4=dphi4*(A*delta4+(d4+g4)*B4*u4-B1*u1-B5*u5);
s5=dphi5*(A*delta5+(d5+g5)*B5*u5-B2*u2-B4*u4);

Y1=delta1'*Q11*delta1+0.25*W6'*dphi1*B1*inv(R11)*B1'*dphi1'*W6+u3'*R13*u3+u4'*R14*u4;
Y2=delta2'*Q22*delta2+0.25*W7'*dphi2*B2*inv(R22)*B2'*dphi2'*W7+u1'*R21*u1;
Y3=delta3'*Q33*delta3+0.25*W8'*dphi3*B3*inv(R33)*B3'*dphi3'*W8+u1'*R31*u1+u2'*R32*u2;
Y4=delta4'*Q44*delta4+0.25*W9'*dphi4*B4*inv(R44)*B4'*dphi4'*W9+u1'*R41*u1+u5'*R45*u5;
Y5=delta5'*Q55*delta5+0.25*W10'*dphi5*B5*inv(R55)*B5'*dphi5'*W10+u2'*R52*u2+u4'*R54*u4;

e1=s1'*W1+Y1;
e2=s2'*W2+Y2;
e3=s3'*W3+Y3;
e4=s4'*W4+Y4;
e5=s5'*W5+Y5;

Win1=-a1*(s1./(s1'*s1+1)^2)*e1;
Win2=-a2*(s2./(s2'*s2+1)^2)*e2;
Win3=-a3*(s3./(s3'*s3+1)^2)*e3;
Win4=-a4*(s4./(s4'*s4+1)^2)*e4;
Win5=-a5*(s5./(s5'*s5+1)^2)*e5;

sbar1=(s1./(s1'*s1+1));
sbar2=(s2./(s2'*s2+1));
sbar3=(s3./(s3'*s3+1));
sbar4=(s4./(s4'*s4+1));
sbar5=(s5./(s5'*s5+1));

ms1=(s1'*s1+1);
ms2=(s2'*s2+1);
ms3=(s3'*s3+1);
ms4=(s4'*s4+1);
ms5=(s5'*s5+1);

D1=dphi1*B1*inv(R11)*B1'*dphi1';
D2=dphi2*B2*inv(R22)*B2'*dphi2';
D3=dphi3*B3*inv(R33)*B3'*dphi3';
D4=dphi4*B4*inv(R44)*B4'*dphi4';
D5=dphi5*B5*inv(R55)*B5'*dphi5';

 F1=5*ones(length(W6),1);
  F2=5*ones(length(W7),1);
   F3=5*ones(length(W8),1);
    F4=5*ones(length(W9),1);
     F5=5*ones(length(W10),1);
 S1=5*eye(length(W6));
  S2=5*eye(length(W7));
   S3=5*eye(length(W8));
    S4=5*eye(length(W9));
     S5=5*eye(length(W10));

% Win6=-a6*(S1*W6-F1.*(sbar1'*W1))+a6*0.25*D1*W6*(sbar1'*inv(ms1))*W1+a6*0.25*(dphi3*inv(R33)*R13*inv(R33)*dphi3'*W6*(s1./(s1'*s1+1)^2)'*W3+dphi4*inv(R44)*R14*inv(R44)*dphi4'*W6*(s1./(s1'*s1+1)^2)'*W4);
% Win7=-a7*(S2*W7-F2.*(sbar2'*W2))+a7*0.25*D2*W7*(sbar2'*inv(ms2))*W2+a7*0.25*(dphi1*inv(R11)*R21*inv(R11)*dphi1'*W7*(s2./(s2'*s2+1)^2)'*W1);
% Win8=-a8*(S3*W8-F3.*(sbar3'*W3))+a8*0.25*D3*W8*(sbar3'*inv(ms3))*W3+a8*0.25*(dphi1*inv(R11)*R31*inv(R11)*dphi1'*W8*(s3./(s3'*s3+1)^2)'*W1+dphi2*inv(R22)*R32*inv(R22)*dphi2'*W8*(s3./(s3'*s3+1)^2)'*W2);
% Win9=-a9*(S4*W9-F4.*(sbar4'*W4))+a9*0.25*D4*W9*(sbar4'*inv(ms4))*W4+a9*0.25*(dphi1*inv(R11)*R41*inv(R11)*dphi1'*W9*(s4./(s4'*s4+1)^2)'*W1+dphi5*inv(R55)*R45*inv(R55)*dphi5'*W9*(s4./(s4'*s4+1)^2)'*W5);
% Win10=-a10*(S5*W10-F5.*(sbar5'*W5))+a10*0.25.*D5*W10*(sbar5'*inv(ms5))*W5+a10*0.25.*(dphi2*inv(R22)*R52*inv(R22)*dphi2'*W10*(s5./(s5'*s5+1)^2)'*W2+dphi4*inv(R44)*R54*inv(R44)*dphi4'*W10*(s5./(s5'*s5+1)^2)'*W4);
Win6=-a6*(S1*W6-F1.*(sbar1'*W1))+a6*0.25*D1*W6*(sbar1'*inv(ms1))*W1+a6*0.25*(((d3+g3)^2)*dphi3*B3*inv(R33)'*R13*inv(R33)*B3'*dphi3'*W6*(s1./(s1'*s1+1)^2)'*W3+((d4+g4)^2)*dphi4*B4*inv(R44)'*R14*inv(R44)*B4'*dphi4'*W6*(s1./(s1'*s1+1)^2)'*W4);
Win7=-a7*(S2*W7-F2.*(sbar2'*W2))+a7*0.25*D2*W7*(sbar2'*inv(ms2))*W2+a7*0.25*(((d1+g1)^2)*dphi1*B1*inv(R11)'*R21*inv(R11)*B1'*dphi1'*W7*(s2./(s2'*s2+1)^2)'*W1);
Win8=-a8*(S3*W8-F3.*(sbar3'*W3))+a8*0.25*D3*W8*(sbar3'*inv(ms3))*W3+a8*0.25*(((d1+g1)^2)*dphi1*B1*inv(R11)'*R31*inv(R11)*B1'*dphi1'*W8*(s3./(s3'*s3+1)^2)'*W1+((d2+g2)^2)*dphi2*B2*inv(R22)'*R32*inv(R22)*B2'*dphi2'*W8*(s3./(s3'*s3+1)^2)'*W2);
Win9=-a9*(S4*W9-F4.*(sbar4'*W4))+a9*0.25*D4*W9*(sbar4'*inv(ms4))*W4+a9*0.25*(((d1+g1)^2)*dphi1*B1*inv(R11)'*R41*inv(R11)*B1'*dphi1'*W9*(s4./(s4'*s4+1)^2)'*W1+((d5+g5)^2)*dphi5*B5*inv(R55)'*R45*inv(R55)*B5'*dphi5'*W9*(s4./(s4'*s4+1)^2)'*W5);
Win10=-a10*(S5*W10-F5.*(sbar5'*W5))+a10*0.25*D5*W10*(sbar5'*inv(ms5))*W5+a10*0.25*(((d2+g2)^2)*dphi2*B2*inv(R22)'*R52*inv(R22)*B2'*dphi2'*W10*(s5./(s5'*s5+1)^2)'*W2+((d4+g4)^2)*dphi4*B4*inv(R44)'*R54*inv(R44)*B4'*dphi4'*W10*(s5./(s5'*s5+1)^2)'*W4);


if t<=80
% unew1=((u1)+1*exp(-0.0*t)*(sin(t)+sin(2*t)));
% unew2=((u2)+1*exp(-0.0*t)*(sin(t)+sin(2*t)));
% unew3=((u3)+1*exp(-0.0*t)*(sin(t)+sin(2*t)));
unew1=((u1)+0*exp(-0.00*t)*(sin(t)^2*cos(t)+sin(2*t)^2*cos(0.1*t)+sin(-1.2*t)^2*cos(0.5*t)+sin(t)^5));
unew2=((u2)+0*exp(-0.00*t)*(sin(t)^2*cos(t)+sin(2*t)^2*cos(0.1*t)+sin(-1.2*t)^2*cos(0.5*t)+sin(t)^5));
unew3=((u3)+0*exp(-0.00*t)*(sin(t)^2*cos(t)+sin(2*t)^2*cos(0.1*t)+sin(-1.2*t)^2*cos(0.5*t)+sin(t)^5));
unew4=((u4)+0*exp(-0.00*t)*(sin(t)^2*cos(t)+sin(2*t)^2*cos(0.1*t)+sin(-1.2*t)^2*cos(0.5*t)+sin(t)^5));
unew5=((u5)+0*exp(-0.00*t)*(sin(t)^2*cos(t)+sin(2*t)^2*cos(0.1*t)+sin(-1.2*t)^2*cos(0.5*t)+sin(t)^5));

else
    
unew1=u1;
unew2=u2;
unew3=u3;
unew4=u4;
unew5=u5;

end
kappa1(i)=u1;
kappa2(i)=u2;
kappa3(i)=u3;
kappa4(i)=u4;
kappa5(i)=u5;
i=i+1;
xout=[A*delta1+(d1+g1)*B1*unew1-B3*unew3-B4*unew4;A*delta2+(d2+g2)*B2*unew2-B1*unew1;A*delta3+(d3+g3)*B3*unew3-B1*unew1-B2*unew2;A*delta4+(d4+g4)*B4*unew4-B1*unew1-B5*unew5;A*delta5+(d5+g5)*B5*unew5-B2*unew2-B4*unew4;Win1;Win2;Win3;Win4;Win5;Win6;Win7;Win8;Win9;Win10;A*x1+B1*unew1;A*x2+B2*unew2;A*x3+B3*unew3;A*x4+B4*unew4;A*x5+B5*unew5;A*x0];

