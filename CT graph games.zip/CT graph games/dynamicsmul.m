function xout=dynamicsmul(t,x)

%global variables
global kappa1;
global kappa2;
global kappa3;
global R11;
global R22;
global R12;
global R21;
global R13;
global R23;
global R33;
global R32;
global R31;
global A;
global B1;
global B2;
global B3;
global B4;
global B5;
global Q11;
global Q22;
global Q33;
global d1;
global d2;
global d3;
global g1;
global g2;
global g3;
global i;


%constants 

a1=3;
a2=3;
a3=3;
a4=1;
a5=1;
a6=1;

delta1=[x(1) x(2)];
delta2=[x(3) x(4)];
delta3=[x(5) x(6)];
W1=[x(7) x(8) x(9)]';
W2=[x(10) x(11) x(12)]';
W3=[x(13) x(14) x(15)]';
W4=[x(16) x(17) x(18)]';
W5=[x(19) x(20) x(21)]';
W6=[x(22) x(23) x(24)]';
x1=[x(25) x(26)];
x2=[x(27) x(28)];
x3=[x(29) x(30)];
x0=[x(31) x(32)];




phix1=[x(1)^2 x(1)*x(2) x(2)^2]';
dphix1=[2*x(1) 0; x(2) x(1); 0 2*x(2)];
phix2=[x(3)^2 x(3)*x(4) x(4)^2]';
dphix2=[x(3) 0; x(4) x(3); 0 2*x(4)];
phix3=[x(5)^2 x(5)*x(6) x(6)^2]';
dphix3=[2*x(5) 0; x(6) x(5); 0 2*x(6)];

u1=-0.5*(d1+g1)*inv(R11)*B1'*dphix1'*W4;
u2=-0.5*(d2+g2)*inv(R22)*B2'*dphix2'*W5;
u3=-0.5*(d3+g3)*inv(R33)*B3'*dphix3'*W6;

s1=dphix1*(A*delta1'+(d1+g1)*B1*u1-B3*u3);
s2=dphix2*(A*delta2'+(d2+g2)*B2*u2-B1*u1);
s3=dphix3*(A*delta3'+(d3+g3)*B3*u3-B1*u1-B2*u2);

Y1=(-delta1*Q11*delta1'-u1*R11*u1'-u3*R13*u3');
Y2=(-delta2*Q22*delta2'-u2*R22*u2'-u1*R21*u1');
Y3=(-delta3*Q33*delta3'-u3*R33*u3'-u1*R31*u1'-u2*R32*u2');

e1=W1'*s1-Y1;
e2=W2'*s2-Y2;
e3=W3'*s3-Y3;


Win1=-a1*(s1./(s1'*s1+1)^2)*e1';
Win2=-a2*(s2./(s2'*s2+1)^2)*e2';
Win3=-a3*(s3./(s3'*s3+1)^2)*e3';


sbar1=(s1/(s1'*s1+1));
sbar2=(s2/(s2'*s2+1));
sbar3=(s3/(s3'*s3+1));

D1=dphix1*B1*inv(R11)*B1'*dphix1';
D2=dphix2*B2*inv(R22)*B2'*dphix2';
D3=dphix3*B3*inv(R33)*B3'*dphix3';

 F1=5*eye(length(W4));
  F2=5*eye(length(W5));
   F3=5*eye(length(W6));

Win4=a4*(F1*W1-F1*W4)-0.25*D1*a4*W4*(s1./(s1'*s1+1)^2)'*W1-0.25*a4*dphix3*inv(R33)*R13*inv(R33)*dphix3'*W4*(s1./(s1'*s1+1)^2)'*W3;
Win5=a5*(F2*W2-F2*W5)-0.25*D2*a5*W5*(s2./(s2'*s2+1)^2)'*W2-0.25*a5*dphix1*inv(R11)*R21*inv(R11)*dphix1'*W5*(s2./(s2'*s2+1)^2)'*W1;
Win6=a6*(F3*W3-F3*W6)-0.25*D3*a6*W6*(s3./(s3'*s3+1)^2)'*W3-0.25*a6*dphix1*inv(R11)*R31*inv(R11)*dphix1'*W6*(s3./(s3'*s3+1)^2)'*W1-0.25*a6*dphix2*inv(R22)*R32*inv(R22)*dphix2'*W6*(s3./(s3'*s3+1)^2)'*W2;

if t<=80
% unew1=((u1)+1*exp(-0.0*t)*(sin(t)+sin(2*t)));
% unew2=((u2)+1*exp(-0.0*t)*(sin(t)+sin(2*t)));
% unew3=((u3)+1*exp(-0.0*t)*(sin(t)+sin(2*t)));
unew1=((u1)+0*exp(-0.00*t)*(sin(t)^2*cos(t)+sin(2*t)^2*cos(0.1*t)+sin(-1.2*t)^2*cos(0.5*t)+sin(t)^5));
unew2=((u2)+0*exp(-0.00*t)*(sin(t)^2*cos(t)+sin(2*t)^2*cos(0.1*t)+sin(-1.2*t)^2*cos(0.5*t)+sin(t)^5));
unew3=((u3)+0*exp(-0.00*t)*(sin(t)^2*cos(t)+sin(2*t)^2*cos(0.1*t)+sin(-1.2*t)^2*cos(0.5*t)+sin(t)^5));

else
    unew1=u1;
unew2=u2;
unew3=u3;

end
kappa1(i)=u1;
kappa2(i)=u2;
kappa3(i)=u3;
i=i+1;
% xout=[A*delta1'+(d1+g1)*B1*unew1-B3*unew3;A*delta2'+(d2+g2)*B2*unew2-B1*u
% new1; A*delta3'+(d3+g3)*B3*unew3-B1*unew1-B2*unew2;Win1 ;Win2; Win3;Win4;Win5;Win6];
xout=[A*delta1'+(d1+g1)*B1*unew1-B3*unew3;A*delta2'+(d2+g2)*B2*unew2-B1*unew1; A*delta3'+(d3+g3)*B3*unew3-B1*unew1-B2*unew2;Win1 ;Win2; Win3;Win4;Win5;Win6;A*x1'+B1*unew1;A*x2'+B2*unew2;A*x3'+B3*unew3;A*x0';A*x1'+B1*unew1;A*x2'+B2*unew2];

