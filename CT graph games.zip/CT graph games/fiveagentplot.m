close all
clear all
clc

% some global 
global kappa1;
global kappa2;
global kappa3;

global R11;
global R13;
global R14;
global R22;
global R21;
global R31;
global R32;
global R33;
global R41;
global R44;
global R45;
global R52;
global R54;
global R55;

global A;
global B1;
global B2;
global B3;
global B4;
global B5;

global Q11;
global Q22;
global Q33;
global Q44;
global Q55;

global d1;
global d2;
global d3;
global d4;
global d5;

global g1;
global g2;
global g3;
global g4;
global g5;
global i;

i=1;

d1=2;
d2=1;
d3=2;
d4=2;
d5=2;
g1=1;
g2=0;
g3=0;
g4=0;
g5=0;
%definitions of R

R11=4;
R13=1;
R14=1;
R22=9;
R31=1;
R21=1;
R32=1;
R33=9;
R41=2;
R44=9;
R45=1;
R52=2;
R54=1;
R55=9;

A=[-2 1; -4 -1];
%definitions of Bi
B1=[2 -1]';
B2=[2 -3]';
B3=[2 0]';
B4=[2 -3]';
B5=[2 0]';


%definitions of Q
Q11=eye(1);
Q22=eye(1);
Q33=eye(1);
Q44=eye(1);
Q55=eye(1);

%initial conditions
x0=[2*pi.*randn(1,10) rand(1,150) 2*pi.*randn(1,12)];

%call ode
  options = odeset('OutputFcn',@odeplot);
  [t,x]= ode23('fiveagent',[0 20],x0,options);
  
  
  %plots
  
%  states
figure (1);
subplot(2,1,1)
plot(t,x(:,161:162));
hold on
plot(t,x(:,171),'r:');
plot(t,x(:,172),'m:');
legend ('x1_1','x1_2','x0_1','x0_2');
xlabel('Time (s)');
subplot(2,1,2)
plot(t,x(:,163:164));
hold on
plot(t,x(:,171),'r:');
plot(t,x(:,172),'m:');
legend ('x2_1','x2_2','x0_1','x0_2');
xlabel('Time (s)');
figure (2);
subplot(3,1,1)
plot(t,x(:,165:166));
hold on
plot(t,x(:,171),'r:');
plot(t,x(:,172),'m:');
legend ('x3_1','x3_2','x0_1','x0_2');
xlabel('Time (s)');
subplot(3,1,2)
plot(t,x(:,167:168));
hold on
plot(t,x(:,171),'r:');
plot(t,x(:,172),'m:');
legend ('x4_1','x4_2','x0_1','x0_2');
xlabel('Time (s)');
subplot(3,1,3)
plot(t,x(:,169:170));
hold on
plot(t,x(:,171),'r:');
plot(t,x(:,172),'m:');
legend ('x5_1','x5_2','x0_1','x0_2');
xlabel('Time (s)');



% figure (2);
% subplot(3,1,1)
% plot(t,x(:,7:9));
% title ('Critic 1');
% xlabel('Time(s)')
% % figure (3);
% subplot(3,1,2)
% plot(t,x(:,10:12));
% title ('Critic 2');
% xlabel('Time(s)')
% % figure (4);
% subplot(3,1,3)
% plot(t,x(:,13:15));
% title ('Critic 3');
% xlabel('Time(s)')
% figure (5);
% 
% plot3(kappa1,kappa2,kappa3);
% 
% title ('Controls');
% 
% 
% figure (6);
% plot(kappa1,'r');
% hold on;
% plot(kappa2,'b');
% hold on;
% plot(kappa3,'y');
% legend ('u1', 'u2','u3');
% 
% figure (7)
% grid on
% plot(x(:,1),x(:,2),'r');
% hold on;
% plot(x(:,3),x(:,4),'b');
% hold on;
% plot(x(:,5),x(:,6),'m');


