close all
clear all
clc

% some global 
global kappa1;
global kappa2;
global kappa3;
global R11;
global R22;
global R12;
global R21;
global R13;
global R23;
global R33;
global R32;
global R31;
global A;
global B1;
global B2;
global B3;
global B4;
global B5;
global Q11;
global Q22;
global Q33;
global d1;
global d2;
global d3;
global g1;
global g2;
global g3;
global i;

i=1;

d1=1;
d2=1;
d3=1;
d4=1;
d5=1;
g1=1;
g2=0;
g3=0;
g4=0;
g5=0;
%definitions of R

R11=1;
R12=1;
R13=1;
R31=1;
R22=1;
R23=1;
R33=1;
R32=1;
R21=1;


A=[-2 1; -4 -1];
%definitions of Bi
B1=[2 -1]';
B2=[2 -3]';
B3=[2 0]';
B4=[2 -3]';
B5=[2 0]';


%definitions of Q
Q11=eye(2);
Q22=eye(2);
Q33=eye(2);

%initial conditions
x0=[2*pi.*[randn(1,6)]  rand(1,3) rand(1,3) rand(1,3)    zeros(1,9) 2*pi.*[randn(1,8) zeros(1,4)]];

%call ode
  options = odeset('OutputFcn',@odeplot);
  [t,x]= ode23('dynamicsmul',[0 20],x0,options);
  
  
  %plots
  
%  states
figure (1);
subplot(3,1,1)
plot(t,x(:,25:26));
hold on
plot(t,x(:,31),'r');
plot(t,x(:,32),'m');
legend ('x_1','x_1_{dot}','x_0','x_0_{dot}');
xlabel('Time (s)');
subplot(3,1,2)
plot(t,x(:,27:28));
hold on
plot(t,x(:,31),'r');
plot(t,x(:,32),'m');
legend ('x_2','x_2_{dot}','x_0','x_0_{dot}');
xlabel('Time (s)');
subplot(3,1,3)
plot(t,x(:,29:30));
hold on
plot(t,x(:,31),'r');
plot(t,x(:,32),'m');
legend ('x_3','x_3_{dot}','x_0','x_0_{dot}');
xlabel('Time (s)');
figure (100)
subplot(2,1,1)
plot(t,x(:,27:28));
hold on
plot(t,x(:,31),'r');
plot(t,x(:,32),'m');
legend ('x_4','x_4_{dot}','x_0','x_0_{dot}');
xlabel('Time (s)');
subplot(2,1,2)
plot(t,x(:,29:30));
hold on
plot(t,x(:,31),'r');
plot(t,x(:,32),'m');
legend ('x_5','x_5_{dot}','x_0','x_0_{dot}');
xlabel('Time (s)');





figure (2);
subplot(3,1,1)
plot(t,x(:,7:9));
title ('Critic 1');
xlabel('Time(s)')
% figure (3);
subplot(3,1,2)
plot(t,x(:,10:12));
title ('Critic 2');
xlabel('Time(s)')
% figure (4);
subplot(3,1,3)
plot(t,x(:,13:15));
title ('Critic 3');
xlabel('Time(s)')
figure (5);

plot3(kappa1,kappa2,kappa3);

title ('Controls');


figure (6);
plot(kappa1,'r');
hold on;
plot(kappa2,'b');
hold on;
plot(kappa3,'y');
legend ('u1', 'u2','u3');

figure (7)
grid on
plot(x(:,1),x(:,2),'r');
hold on;
plot(x(:,3),x(:,4),'b');
hold on;
plot(x(:,5),x(:,6),'m');


