close all;clear all;clc;

global W;
load W.txt;
global A;
A=2;
ti=0;
tf=100;
tspan=[ti tf];
%for ii=1:100
x0=[-1.0 1.7 1.5 1.0 0 0]*0;
%x0=[1 0 1 0 0 0];
%x0=[-1.0 1 -1 1.0 0 0];


options=odeset('RelTol',1e-8);
[t,x]= ode45('RTACfile',tspan,[x0],options);
figure(1);hold on;
ylabel('x_1,x_3');xlabel('Time in seconds');%title('No title yet');
plot(t,x(:,1),'b-','LineWidth',2);
plot(t,x(:,3),'r-.','LineWidth',2);
legend('r','theta');
title('Nearly Optimal Controller State Trajectories');
title('Initial Controller State Trajectories');

figure(2);hold on;
ylabel('x_2,x_4');xlabel('Time in seconds');%title('No title yet');
plot(t,x(:,2),'b-','LineWidth',2);
plot(t,x(:,4),'r-.','LineWidth',2);
legend('rdot','thetadot');
title('Nearly Optimal Controller State Trajectories');
title('Initial Controller State Trajectories');

figure(3);hold on;
for i=1:length(x)
    x1=x(i,1);x2=x(i,2);x3=x(i,3);x4=x(i,4);
    dPHI=[   2*x1            0               0               0
                x2              x1              0               0
                x3              0               x1              0
                x4              0               0               x1              
                0               2*x2            0               0                
                0               x3              x2              0
                0               x4              0               x2
                0               0               2*x3            0                
                0               0               x4              x3
                0               0               0               2*x4
                
                4*x1^3          0               0               0
                3*x1^2*x2       x1^3            0               0
                3*x1^2*x3       0               x1^3            0
                3*x1^2*x4       0               0               x1^3
                2*x1*x2^2       2*x1^2*x2       0               0
                2*x1*x2*x3      x1^2*x3         x1^2*x2         0
                2*x1*x2*x4      x1^2*x4         0               x1^2*x2
                2*x1*x3^2       0               2*x1^2*x3       0
                2*x1*x3*x4      0               x1^2*x4         x1^2*x3
                2*x1*x4^2       0               0               2*x1^2*x4
                x2^3            3*x1*x2^2       0               0
                x2^2*x3         2*x1*x2*x3      x1*x2^2         0
                x2^2*x4         2*x1*x2*x4      0               x1*x2^2
                x2*x3^2         x1*x3^2         2*x1*x2*x3      0
                x2*x3*x4        x1*x3*x4        x1*x2*x4        x1*x2*x3
                x2*x4^2         x1*x4^2         0               2*x1*x2*x4
                x3^3            0               3*x1*x3^2       0
                x3^2*x4         0               2*x1*x3*x4      x1*x3^2
                x3*x4^2         0               x1*x4^2         2*x1*x3*x4
                x4^3            0               0               3*x1*x4^2
                0               4*x2^3          0               0
                0               3*x2^2*x3       x2^3            0
                0               3*x2^2*x4       0               x2^3
                0               2*x2*x3^2       2*x2^2*x3       0
                0               2*x2*x3*x4      x2^2*x4         x2^2*x3
                0               2*x2*x4^2       0               2*x2^2*x4
                0               x3^3            3*x2*x3^2       0
                0               x3^2*x4         2*x2*x3*x4      x2*x3^2
                0               x3*x4^2         x2*x4^2         2*x2*x3*x4
                0               x4^3            0               3*x2*x4^2
                0               0               4*x3^3          0
                0               0               3*x3^2*x4       x3^3
                0               0               2*x3*x4^2       2*x3^2*x4
                0               0               x4^3            3*x3*x4^2
                0               0               0               4*x4^3
                
                6*x1^5          0               0               0
                5*x1^4*x2       x1^5            0               0
                5*x1^4*x3       0               x1^5            0
                5*x1^4*x4       0               0               x1^5
                4*x1^3*x2^2     2*x1^4*x2       0               0
                4*x1^3*x2*x3    x1^4*x3         x1^4*x2         0
                4*x1^3*x2*x4    x1^4*x4         0               x1^4*x2
                4*x1^3*x3^2     0               2*x1^4*x3       0
                4*x1^3*x3*x4    0               x1^4*x4         x1^4*x3
                4*x1^3*x4^2     0               0               2*x1^4*x4
                3*x1^2*x2^3     3*x1^3*x2^2     0               0
                3*x1^2*x2^2*x3  2*x1^3*x2*x3    x1^3*x2^2       0
                3*x1^2*x2^2*x4  2*x1^3*x2*x4    0               x1^3*x2^2
                3*x1^2*x2*x3^2  x1^3*x3^2       2*x1^3*x2*x3    0
                3*x1^2*x2*x3*x4 x1^3*x3*x4      x1^3*x2*x4      x1^3*x2*x3
                3*x1^2*x2*x4^2  x1^3*x4^2       0               2*x1^3*x2*x4
                3*x1^2*x3^3     0               3*x1^3*x3^2     0
                3*x1^2*x3^2*x4  0               2*x1^3*x3*x4    x1^3*x3^2
                3*x1^2*x3*x4^2  0               x1^3*x4^2       2*x1^3*x3*x4
                3*x1^2*x4^3     0               0               3*x1^3*x4^2
                2*x1*x2^4       4*x1^2*x2^3     0               0
                2*x1*x2^3*x3    3*x1^2*x2^2*x3  x1^2*x2^3       0
                2*x1*x2^3*x4    3*x1^2*x2^2*x4  0               x1^2*x2^3
                2*x1*x2^2*x3^2  2*x1^2*x2*x3^2  2*x1^2*x2^2*x3  0
                2*x1*x2^2*x3*x4 2*x1^2*x2*x3*x4 x1^2*x2^2*x4    x1^2*x2^2*x3
                2*x1*x2^2*x4^2  2*x1^2*x2*x4^2  0               2*x1^2*x2^2*x4
                2*x1*x2*x3^3    x1^2*x3^3       3*x1^2*x2*x3^2  0
                2*x1*x2*x3^2*x4 x1^2*x3^2*x4    2*x1^2*x2*x3*x4 x1^2*x2*x3^2
                2*x1*x2*x3*x4^2 x1^2*x3*x4^2    x1^2*x2*x4^2    2*x1^2*x2*x3*x4
                2*x1*x2*x4^3    x1^2*x4^3       0               3*x1^2*x2*x4^2
                2*x1*x3^4       0               4*x1^2*x3^3     0
                2*x1*x3^3*x4    0               3*x1^2*x3^2*x4  x1^2*x3^3
                2*x1*x3^2*x4^2  0               2*x1^2*x3*x4^2  2*x1^2*x3^2*x4
                2*x1*x3*x4^3    0               x1^2*x4^3       3*x1^2*x3*x4^2
                2*x1*x4^4       0               0               4*x1^2*x4^3
                x2^5            5*x1*x2^4       0               0
                x2^4*x3         4*x1*x2^3*x3    x1*x2^4         0
                x2^4*x4         4*x1*x2^3*x4    0               x1*x2^4
                x2^3*x3^2       3*x1*x2^2*x3^2  2*x1*x2^3*x3    0
                x2^3*x3*x4      3*x1*x2^2*x3*x4 x1*x2^3*x4      x1*x2^3*x3
                x2^3*x4^2       3*x1*x2^2*x4^2  0               2*x1*x2^3*x4
                x2^2*x3^3       2*x1*x2*x3^3    3*x1*x2^2*x3^2  0
                x2^2*x3^2*x4    2*x1*x2*x3^2*x4 2*x1*x2^2*x3*x4 x1*x2^2*x3^2
                x2^2*x3*x4^2    2*x1*x2*x3*x4^2 x1*x2^2*x4^2    2*x1*x2^2*x3*x4
                x2^2*x4^3       2*x1*x2*x4^3    0               3*x1*x2^2*x4^2
                x2*x3^4         x1*x3^4         4*x1*x2*x3^3    0
                x2*x3^3*x4      x1*x3^3*x4      3*x1*x2*x3^2*x4 x1*x2*x3^3
                x2*x3^2*x4^2    x1*x3^2*x4^2    2*x1*x2*x3*x4^2 2*x1*x2*x3^2*x4
                x2*x3*x4^3      x1*x3*x4^3      x1*x2*x4^3      3*x1*x2*x3*x4^2
                x2*x4^4         x1*x4^4         0               4*x1*x2*x4^3
                x3^5            0               5*x1*x3^4       0
                x3^4*x4         0               4*x1*x3^3*x4    x1*x3^4
                x3^3*x4^2       0               3*x1*x3^2*x4^2  2*x1*x3^3*x4
                x3^2*x4^3       0               2*x1*x3*x4^3    3*x1*x3^2*x4^2
                x3*x4^4         0               x1*x4^4         4*x1*x3*x4^3
                x4^5            0               0               5*x1*x4^4
                0               6*x2^5          0               0
                0               5*x2^4*x3       x2^5            0
                0               5*x2^4*x4       0               x2^5
                0               4*x2^3*x3^2     2*x2^4*x3       0
                0               4*x2^3*x3*x4    x2^4*x4         x2^4*x3
                0               4*x2^3*x4^2     0               2*x2^4*x4
                0               3*x2^2*x3^3     3*x2^3*x3^2     0
                0               3*x2^2*x3^2*x4  2*x2^3*x3*x4    x2^3*x3^2
                0               3*x2^2*x3*x4^2  x2^3*x4^2       2*x2^3*x3*x4
                0               3*x2^2*x4^3     0               3*x2^3*x4^2
                0               2*x2*x3^4       4*x2^2*x3^3     0
                0               2*x2*x3^3*x4    3*x2^2*x3^2*x4  x2^2*x3^3
                0               2*x2*x3^2*x4^2  2*x2^2*x3*x4^2  2*x2^2*x3^2*x4
                0               2*x2*x3*x4^3    x2^2*x4^3       3*x2^2*x3*x4^2
                0               2*x2*x4^4       0               4*x2^2*x4^3
                0               x3^5            5*x2*x3^4       0
                0               x3^4*x4         4*x2*x3^3*x4    x2*x3^4
                0               x3^3*x4^2       3*x2*x3^2*x4^2  2*x2*x3^3*x4
                0               x3^2*x4^3       2*x2*x3*x4^3    3*x2*x3^2*x4^2
                0               x3*x4^4         x2*x4^4         4*x2*x3*x4^3
                0               x4^5            0               5*x2*x4^4
                0               0               6*x3^5          0
                0               0               5*x3^4*x4       x3^5
                0               0               4*x3^3*x4^2     2*x3^4*x4
                0               0               3*x3^2*x4^3     3*x3^3*x4^2
                0               0               2*x3*x4^4       4*x3^2*x4^3
                0               0               x4^5            5*x3*x4^4
                0               0               0               6*x4^5];
    
                EPS=0.2;
                beta_x=-x1+EPS*x4^2*sin(x3);
                gamma_x=1-EPS^2*cos(x3)^2;
    
 
 g=[  0;
      -EPS*cos(x3)/gamma_x
      0
      1/gamma_x];
    u(i)=A*tanh(1/A*-0.5*g'*dPHI'*W);
end
K=[2.41817 1.16494 -.34158 -1.08667];
%K=-[-1.3862   -0.0271    1.0000    1.8634];

u=A*tanh(K*x(:,1:4)'/A);
ylabel('control');xlabel('Time in seconds');title('No title yet');
plot(t,u,'r-.','LineWidth',2);
title('Nearly Optimal Controller');
title('Initial Controller');


figure(4);hold on;
ylabel('Attenuation');xlabel('Time in seconds');%title('No title yet');
plot(t(10:length(t)),x(10:length(t),5)./x(10:length(t),6),'r-.','LineWidth',2);
title('Nearly Optimal Controller Cost');
title('Initial Controller Cost');


%end