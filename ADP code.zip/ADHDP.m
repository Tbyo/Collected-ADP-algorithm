% Implementation of ADHDP (Q-Learning) algorithm in Landelius Dissertation and papers.
% September 4th, 2005.
% Prepared by: MAK

% Cosider the following discrete time system
% x(k+1)=[0      1; -0.16 -1]*x(k)+[0;1]*u(k)
% L=[.34 -2];
close all;clc;clear all;
figure;hold on;

% This is just to simulate the system
A=[0 1;-0.16 -1];
B=[0;1];
L=[.34 -2];
R=1;P=eye(2,2);G=[P [0 ; 0];[0 0] R];
x=[10;-10];
plot(0,x(1),'.');plot(0,x(2),'.')
for i=1:20
    x(:,i+1)=A*x(:,i)-B*L*x(:,i);
end
plot((1:21)-1,x(1,:));plot((1:21)-1,x(2,:));
plot((1:21)-1,x(1,:),'.');plot((1:21)-1,x(2,:),'.');

% This is to verify that the iteration that appears in Landelius makes sense.
Hxx(1:2,1:2)=0;Hxy(1:2,1)=0;Hyx(1,1:2)=0;Hyy=0;
H=[Hxx Hxy;Hyx Hyy];L=[0 0];
for i=1:20
    H=G+[A B;L*A L*B]'*H*[A B;L*A L*B];
    Hyy=H(3,3);Hyx=H(3,1:2);
    L=-inv(Hyy)*Hyx;
end
% solution of DARE
H
K=dare(A,B,P,R)

% OR to solve in we can intialize as follows:
% % This is just to simulate the system
% A=[0 1;-0.16 -1];
% B=[0;1];
% R=1;P=eye(2,2);G=[P [0 ; 0];[0 0] R];
% H=[1 0 0;0 1 0;1 0 1];
% for i=1:20
%     Hyy=H(3,3);Hyx=H(3,1:2);
%     L=-inv(Hyy)*Hyx;
%     H=G+[A B;L*A L*B]'*H*[A B;L*A L*B]    
% end

% This is to perform the ADHDP algorithm
clear x;
x=[10;-10];
H=[1 0 0;0 1 0;1 0 1];
Hyy=H(3,3);Hyx=H(3,1:2);L=-inv(Hyy)*Hyx;
zbar(1:6,1:7)=0;d_target(1:7,1)=0;
for i=1:40
    u=L*x(:,i)+0.01*randn;
    Z(:,i)=[x(:,i);u];
    x(:,i+1)=A*x(:,i)+B*u;
    d_target(1,1)=d_target(2,1);
    d_target(2,1)=d_target(3,1);
    d_target(3,1)=d_target(4,1);
    d_target(4,1)=d_target(5,1);    % the more you include the better
    d_target(5,1)=d_target(6,1);
    d_target(6,1)=d_target(7,1);    
    d_target(7,1)=[x(:,i); u]'*G*[x(:,i); u]+[x(:,i+1);L*x(:,i+1)]'*H*[x(:,i+1);L*x(:,i+1)];
    zbar(:,1)=zbar(:,2);
    zbar(:,2)=zbar(:,3);
    zbar(:,3)=zbar(:,4);
    zbar(:,4)=zbar(:,5);
    zbar(:,5)=zbar(:,6);
    zbar(:,6)=zbar(:,7);
    zbar(:,7)=[x(1,i)^2;x(1,i)*x(2,i);x(1,i)*u;x(2,i)^2;x(2,i)*u;u^2];
    if mod(i,7)==0
        C=zbar*zbar';q=zbar*d_target;
        rank(C)
        vH=inv(C)*q;
        H=[vH(1,1) vH(2,1)/2 vH(3,1)/2; vH(2,1)/2 vH(4,1) vH(5,1)/2;vH(3,1)/2 vH(5,1)/2 vH(6,1)]
        Hyy=H(3,3);Hyx=H(3,1:2);
        L=-inv(Hyy)*Hyx;          % Here is when we need the plant dynamics in ADHDP
    end
end
figure;hold on;
plot((1:41)-1,x(1,:));plot((1:41)-1,x(2,:));
plot((1:41)-1,x(1,:),'.');plot((1:41)-1,x(2,:),'.');


% H =
% 
%     1.0256    0.1600   -0.1600
%     0.1600    3.0000   -1.0000
%    -0.1600   -1.0000    2.0000