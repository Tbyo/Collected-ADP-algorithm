% Implementation of HDP algorithm in Landelius Dissertation and papers.
% September 4th, 2005.
% Prepared by: MAK

% Cosider the following discrete time system
% x(k+1)=[0      1; -0.16 -1]*x(k)+[0;1]*u(k)
% L=[.34 -2];
close all;clc;clear all;
figure;hold on;

% This is just to simulate the system
A=[0 1;-0.16 -1];
B=[0;1];
L=[.34 -2];
R=1;P=eye(2,2);
x=[10;-10];
plot(0,x(1),'.');plot(0,x(2),'.')
for i=1:20
    x(:,i+1)=A*x(:,i)-B*L*x(:,i);
end
plot((1:21)-1,x(1,:));plot((1:21)-1,x(2,:));
plot((1:21)-1,x(1,:),'.');plot((1:21)-1,x(2,:),'.');

% This is to verify that the iteration that appears in Landelius makes sense.
K=0.1*eye(2,2);
for i=1:20
    L=-inv(R+B'*K*B)*B'*K*A;
    K=P+L'*R*L+(A+B*L)'*K*(A+B*L);
end
K  % solution of DARE
dare(A,B,P,R)

% This is to perform the HDP algorithm
clear x;
x=[10;-10];
K=0*eye(2,2);L=-inv(R+B'*K*B)*B'*K*A;%L=[0 0];
xbar(1:3,1:3)=0;d_target(1:3,1)=0;
for i=1:20
    u=L*x(:,i);    
    x(:,i+1)=A*x(:,i)+B*u;
    d_target(1,1)=d_target(2,1);
    d_target(2,1)=d_target(3,1);
    d_target(3,1)=x(:,i)'*P*x(:,i)+u*R*u+x(:,i+1)'*K*x(:,i+1);
    xbar(:,1)=xbar(:,2);
    xbar(:,2)=xbar(:,3);
    xbar(:,3)=[x(1,i)^2;x(1,i)*x(2,i);x(2,i)^2];
    if mod(i,3)==0        
        C=xbar*xbar';q=xbar*d_target;        
        vK=inv(C)*q;
        K=[vK(1) vK(2)/2;vK(2)/2 vK(3)];
        L=-inv(R+B'*K*B)*B'*K*A;          % Here is when we need the plant dynamics in HDP
    end
end
figure;hold on;
plot((1:21)-1,x(1,:));plot((1:21)-1,x(2,:));
plot((1:21)-1,x(1,:),'.');plot((1:21)-1,x(2,:),'.');