% Implementation of DHP algorithm in Landelius Dissertation and papers.
% September 4th, 2005.
% Prepared by: MAK

% Cosider the following discrete time system
% x(k+1)=[0      1; -0.16 -1]*x(k)+[0;1]*u(k)
% L=[.34 -2];
close all;clc;clear all;
figure;hold on;

% This is just to simulate the system
A=[0 1;-0.16 -1];
B=[0;1];
L=[.34 -2];
R=1;P=eye(2,2);
x=[10;-10];
plot(0,x(1),'.');plot(0,x(2),'.')
for i=1:20
    x(:,i+1)=A*x(:,i)-B*L*x(:,i);
end
plot((1:21)-1,x(1,:));plot((1:21)-1,x(2,:));
plot((1:21)-1,x(1,:),'.');plot((1:21)-1,x(2,:),'.');

% This is to verify that the iteration that appears in Landelius makes sense.
K=0.1*eye(2,2);
for i=1:20
    L=-inv(R+B'*K*B)*B'*K*A;
    K=P+L'*R*L+(A+B*L)'*K*(A+B*L);
end
K  % solution of DARE
dare(A,B,P,R)

% This is to perform the DHP algorithm
clear x;
x=[10;-10];
K=0*eye(2,2);L=-inv(R+B'*K*B)*B'*K*A;
d_target(1:2,1:2)=0;
for i=1:20
    u=L*x(:,i);    
    x(:,i+1)=A*x(:,i)+B*u;
    d_target(1,:)=d_target(2,:);
    d_target(2,:)=2*x(:,i)'*P+2*u'*R*L+2*x(:,i+1)'*K*(A+B*L);
    if mod(i,2)==0        
        C= 2*x(:,i-1:i)*x(:,i-1:i)';q=x(:,i-1:i)*d_target;        
        K=inv(C)*q;
        L=-inv(R+B'*K*B)*B'*K*A;          % Here is when we need the plant dynamics in DHP
    end
end
K
figure;hold on;
plot((1:21)-1,x(1,:));plot((1:21)-1,x(2,:));
plot((1:21)-1,x(1,:),'.');plot((1:21)-1,x(2,:),'.');