clc
clear
close all
global kp tau Cf Lf rLf Lc rLc mp1 mp2 mp3 Pmax4 Pmax5 Pmax6 Pmax7 nq1 nq2 nq3 Qmax4 Qmax5 Qmax6 Qmax7 Kpv1 Kiv1 Kpc1 Kic1 Kpv2 Kiv2 Kpc2 Kic2 Kpv3 Kiv3 Kpc3 Kic3 Kpc4 Kic4 Kpc5 Kic5 Kpc6 Kic6 Kpc7 Kic7 wc F rN wn1 wn2 wn3 wb wref Vdref rline1 Lline1 rline2 Lline2 rline3 Lline3 rline4 Lline4 rline5 Lline5 rline6 Lline6 rline7 Lline7 Rload1 Lload1 Rload2 Lload2 Rload3 Lload3 Rload4 Lload4
%%%--------Parameter values--------------
Cf=50e-6;Lf=1.35e-3;rLf=.1;
Lc=.35e-3;rLc=.03;
wc=31.41;
mp1=9.4e-5;mp2=mp1;mp3=12.5e-5;
Pmax4=8000;Pmax5=8000;Pmax6=8000;Pmax7=8000;

nq1=1.3e-3;nq2=nq1;nq3=1.5e-3;
Qmax4=8000;Qmax5=8000;Qmax6=8000;Qmax7=8000;

Kpv1=.1;Kiv1=420;Kpv2=Kpv1;Kiv2=Kiv1;
Kpc1=15;Kic1=20*10^3;Kpc2=Kpc1;Kic2=Kic1;
Kpc5=15;Kic5=20*10^3;Kpc6=Kpc5;Kic6=Kic5;

Kpv3=.05;Kiv3=390;
Kpc3=10.5;Kic3=16*10^3;Kpc4=Kpc3;Kic4=Kic3;
Kpc7=15;Kic7=20*10^3;

F=.75;

kp=285;tau=0.00002;
%---------------
rN=1e4;
wb=2*pi*50;
wref=2*pi*50;

Vn=380;
Vdref=1*Vn;
Vqref=0;
%-----Network Data-------
rline1=.23;Lline1=.1/(2*pi*50);
rline2=.35;Lline2=.58/(2*pi*50);
rline3=.23;Lline3=.1/(2*pi*50);
rline4=.35;Lline4=.58/(2*pi*50);
rline5=.23;Lline5=.1/(2*pi*50);
rline6=.35;Lline6=.58/(2*pi*50);
rline7=.23;Lline7=.1/(2*pi*50);

Rload1=5;
Lload1=5/(2*pi*50);
Rload2=5;
Lload2=3/(2*pi*50);
Rload3=5;
Lload3=5/(2*pi*50);
Rload4=5;
Lload4=3/(2*pi*50);

%------------------------------------


x0=0.001*ones(88,1);


%------------------------------------
%options=odeset('Abstol', 1e-6);
[t,x]=ode23tb('sevendg_volcontrol_func',[0 0.01],x0);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%---------------Outputs------------------------


for i=1:3
    vbus(:,i)=sqrt(x(:,13*(i-1)+10).^2+x(:,13*(i-1)+11).^2);
end
% for i=1:4
%     PDG(:,i)=x(:,9*(i-1)+6+40).*x(:,9*(i-1)+8+40)+x(:,9*(i-1)+7+40).*x(:,9*(i-1)+9+40);
%     QDG(:,i)=-x(:,9*(i-1)+6+40).*x(:,+9*(i-1)+9+40)+x(:,9*(i-1)+7+40).*x(:,9*(i-1)+8+40);
% end

% figure;
% plot(t,PDG(:,1));title('PDG4,PDG5,PDG6,PDG7');
% hold on
% plot(t,PDG(:,2),'g:');
% hold on
% plot(t,PDG(:,3),'r--');
% hold on
% plot(t,PDG(:,4),'k-.');

% figure;
% plot(t,QDG(:,1));title('QDG4,QDG5,QDG6,QDG7');
% hold on
% plot(t,QDG(:,2),'g:');
% hold on
% plot(t,QDG(:,3),'r--');
% hold on
% plot(t,QDG(:,4),'k-.');

figure;
plot(t,vbus(:,1));title('Vod1,Vod2,Vod3');
hold on
plot(t,vbus(:,2),'g:');
hold on
plot(t,vbus(:,3),'r--');

w1=2*pi*50-mp1*x(:,2);
w2=2*pi*50-mp2*x(:,15);
w3=2*pi*50-mp3*x(:,28);

figure;
plot(t,w1);title('w1,w2,w3');
hold on
plot(t,w2,'g:');
hold on
plot(t,w3,'r--');

figure;
plot(t,x(:,44));title('iod4,iod5,iod6,iod7');
hold on
plot(t,x(:,50),'g:');
hold on
plot(t,x(:,56),'r--');
hold on
plot(t,x(:,62),'k-.');

figure;
plot(t,x(:,45));title('ioq4,ioq5,ioq6,ioq7');
hold on
plot(t,x(:,51),'g:');
hold on
plot(t,x(:,57),'r--');
hold on
plot(t,x(:,63),'k-.');

ioD1=cos(0)*x(:,12)-sin(0)*x(:,13);
ioQ1=sin(0)*x(:,12)+cos(0)*x(:,13);
ioD2=cos(x(:,14)).*x(:,25)-sin(x(:,14)).*x(:,26);
ioQ2=sin(x(:,14)).*x(:,25)+cos(x(:,14)).*x(:,26);
ioD3=cos(x(:,27)).*x(:,38)-sin(x(:,27)).*x(:,39);
ioQ3=sin(x(:,27)).*x(:,38)+cos(x(:,27)).*x(:,39);
ioD4=cos(x(:,40)).*x(:,44)-sin(x(:,40)).*x(:,45);
ioQ4=sin(x(:,40)).*x(:,44)+cos(x(:,40)).*x(:,45);
ioD5=cos(x(:,46)).*x(:,50)-sin(x(:,46)).*x(:,51);
ioQ5=sin(x(:,46)).*x(:,50)+cos(x(:,46)).*x(:,51);
ioD6=cos(x(:,52)).*x(:,56)-sin(x(:,52)).*x(:,57);
ioQ6=sin(x(:,52)).*x(:,56)+cos(x(:,52)).*x(:,57);
ioD7=cos(x(:,58)).*x(:,62)-sin(x(:,58)).*x(:,63);
ioQ7=sin(x(:,58)).*x(:,62)+cos(x(:,58)).*x(:,63);

%%----------Defining Bus Voltages-----------------
vbD1=rN*(ioD1+x(:,64)-x(:,66)-x(:,78));vbQ1=rN*(ioQ1+x(:,65)-x(:,67)-x(:,79));
vbD2=rN*(ioD2+x(:,70)+x(:,74)-x(:,72)-x(:,82));vbQ2=rN*(ioQ2+x(:,71)+x(:,75)-x(:,73)-x(:,83));
vbD3=rN*(ioD3+x(:,72)+x(:,76)-x(:,84));vbQ3=rN*(ioQ3+x(:,73)+x(:,77)-x(:,85));
vbD4=rN*(ioD4-x(:,64));vbQ4=rN*(ioQ4-x(:,65));
vbD5=rN*(ioD5-x(:,68));vbQ5=rN*(ioQ5-x(:,69));
vbD6=rN*(ioD6-x(:,74));vbQ6=rN*(ioQ6-x(:,75));
vbD7=rN*(ioD7-x(:,76));vbQ7=rN*(ioQ7-x(:,77));
vbD8=rN*(x(:,66)+x(:,68)-x(:,70)-x(:,80));vbQ8=rN*(x(:,67)+x(:,69)-x(:,71)-x(:,81));

%%----------Transferring Bus Voltages to Inv. dq-----------------
vbd1=cos(0)*vbD1+sin(0)*vbQ1;vbq1=-sin(0)*vbD1+cos(0)*vbQ1;
vbd2=cos(x(:,14)).*vbD2+sin(x(:,14)).*vbQ2;vbq2=-sin(x(:,14)).*vbD2+cos(x(:,14)).*vbQ2;
vbd3=cos(x(:,27)).*vbD3+sin(x(:,27)).*vbQ3;vbq3=-sin(x(:,27)).*vbD3+cos(x(:,27)).*vbQ3;
vbd4=cos(x(:,40)).*vbD4+sin(x(:,40)).*vbQ4;vbq4=-sin(x(:,40)).*vbD4+cos(x(:,40)).*vbQ4;
vbd5=cos(x(:,46)).*vbD5+sin(x(:,46)).*vbQ5;vbq5=-sin(x(:,46)).*vbD5+cos(x(:,46)).*vbQ5;
vbd6=cos(x(:,52)).*vbD6+sin(x(:,52)).*vbQ6;vbq6=-sin(x(:,52)).*vbD6+cos(x(:,52)).*vbQ6;
vbd7=cos(x(:,58)).*vbD7+sin(x(:,58)).*vbQ7;vbq7=-sin(x(:,58)).*vbD7+cos(x(:,58)).*vbQ7;

figure;
plot(t,vbd4);title('vbd4,vbd5,vbd6,vbd7');
hold on
plot(t,vbd5,'g:');
hold on
plot(t,vbd6,'r--');
hold on
plot(t,vbd7,'k-.');

figure;
plot(t,vbq4);title('vbq4,vbq5,vbq6,vbq7');
hold on
plot(t,vbq5,'g:');
hold on
plot(t,vbq6,'r--');
hold on
plot(t,vbq7,'k-.');
