close all
%---frequency plot----------

f1=frequency.signals(1,1).values/(2*pi);
f2=frequency.signals(1,2).values/(2*pi);
f3=frequency.signals(1,3).values/(2*pi);

figure;
subplot(2,1,1), plot(tout,f1,tout,f2,'r:',tout,f3,'k--','LineWidth',2);ylabel('f(Hz)');xlabel('t(s)');legend('DG1','DG2','DG3');

aP1=aP13.signals(1,1).values;
aP2=aP13.signals(1,2).values;
aP3=aP13.signals(1,3).values;

subplot(2,1,2), plot(tout,aP1,tout,aP2,'r:',tout,aP3,'k--','LineWidth',2);xlabel('t(s)');ylabel('m_p*P');

% vbd4=vb4.signals(1,1).values;vbq4=vb4.signals(1,2).values;
% vbd5=vb5.signals(1,1).values;vbq5=vb5.signals(1,2).values;
% vbd6=vb6.signals(1,1).values;vbq6=vb6.signals(1,2).values;
% vbd7=vb7.signals(1,1).values;vbq7=vb7.signals(1,2).values;
% 
% figure;
% plot(tout,-vbd4/380,tout,-vbd5/380,'r:',tout,-vbd6/380,'k--',tout,-vbd7/380,'g-.','LineWidth',2);xlabel('t(s)');ylabel('v_o_,_m_a_g(pu)');legend('DG4','DG5','DG6','DG7');
% 
% figure;
% plot(tout,vbq4,tout,vbq5,'r:',tout,vbq6,'k--',tout,vbq7,'g-.','LineWidth',2);xlabel('t(s)');ylabel('v_b_q(V)');legend('DG4','DG5','DG6','DG7');

aP4=aP47.signals(1,1).values;aP5=aP47.signals(1,2).values;aP6=aP47.signals(1,3).values;
aQ4=aQ47.signals(1,1).values;aQ5=aQ47.signals(1,2).values;aQ6=aQ47.signals(1,3).values;

figure;
subplot(2,1,1), plot(tout,aP4,tout,aP5,'r:',tout,aP6,'g:','LineWidth',2);ylabel('P/P_m_a_x');xlabel('t(s)');legend('DG4','DG5','DG6');

subplot(2,1,2), plot(tout,aQ4,tout,aQ5,'r:',tout,aQ6,'g:','LineWidth',2);xlabel('t(s)');ylabel('Q/Q_m_a_x');

vmag1=vomag13.signals(1,1).values;
vmag2=vomag13.signals(1,2).values;
vmag3=vomag13.signals(1,3).values;
aQ1=aQ13.signals(1,1).values;
aQ2=aQ13.signals(1,2).values;
aQ3=aQ13.signals(1,3).values;

v4=vb4.signals(1,1).values;

figure;
subplot(2,1,1), plot(tout,vmag1,tout,vmag2,'r:',tout,vmag3,'k--','LineWidth',2);ylabel('v_o_,_m_a_g(pu)');xlabel('t(s)');legend('DG1','DG2','DG3');
%subplot(2,1,1), plot(tout,v4/480,'LineWidth',2);ylabel('v_c_,_m_a_g');
subplot(2,1,2), plot(tout,aQ1,tout,aQ2,'r:',tout,aQ3,'k--','LineWidth',2);xlabel('t(s)');ylabel('n_q*Q');
